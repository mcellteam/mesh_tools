#ifndef FILTER_H
#define FILTER_H

void median_filter33(float *buf, int dimx, int dimy);

void lowpass_filter33(float *buf, int dimx, int dimy);

#endif
