#ifndef BRANCH_UTIL_H
#define BRANCH_UTIL_H

# include "common.h"

int process_an_untiled_region(VertType *vert_ary, short * group_ary,
							  short poly_num);

#endif

