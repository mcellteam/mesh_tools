#ifndef QSORT_H
#define QSORT_H

int quick_sort(double *val_ary, int *index_ary, int index);

#endif
