#ifndef MAIN_H
#define MAIN_H

void print_usage(char *p);

int parse_argv(int argc, char **argv);

void handle_fatal_error();

#endif
